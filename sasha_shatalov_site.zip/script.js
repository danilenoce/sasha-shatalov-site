const quotes = [
    "Если проблема не решается, значит, это не твоя проблема.",
    "Саша Шаталов не опаздывает. Время просто не успевает за ним.",
    "Я не ленивый, я в режиме энергосбережения.",
    "Когда я думаю — мир замирает, потому что боится, что я придумаю что-то гениальное.",
    "Можно делать плохо, можно делать хорошо, а можно вообще не делать. Я выбираю третий вариант."
];

function newQuote() {
    const quoteText = document.getElementById("quote");
    const randomIndex = Math.floor(Math.random() * quotes.length);
    quoteText.innerText = quotes[randomIndex];
}

function shareSite() {
    const url = window.location.href;
    navigator.clipboard.writeText(url);
    alert("Ссылка на сайт скопирована!");
}

window.onload = newQuote;